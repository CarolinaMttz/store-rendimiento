export const environment = {
  production: true,
  url_api: 'https://store.nicobytes.site/api',
  firebase: {
    apiKey: 'AIzaSyCN599W6_flBEpe0xrcuBlGPRW3OKzDr7o',
    authDomain: 'platzi-store-forms.firebaseapp.com',
    databaseURL: 'https://platzi-store-forms.firebaseio.com',
    projectId: 'platzi-store-forms',
    storageBucket: 'platzi-store-forms.appspot.com',
    messagingSenderId: '783669493891',
    appId: '1:783669493891:web:f973c1ba9bb213e2c75bb6'
  }
};
